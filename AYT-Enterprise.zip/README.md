# AYT এন্টারপ্রাইজ

## APK বানানোর নিয়ম (GitHub)
1. GitHub-এ নতুন repository খুলুন।
2. ZIP ফাইল Extract করে ভেতরের সব ফাইল ও ফোল্ডার (লুকানো `.github` সহ) repository-তে আপলোড করুন (main branch)।
3. উপরের **Actions** ট্যাবে যান। "Build APK" নিজে চলবে (না চললে Run workflow চাপুন)।
4. ৫-১০ মিনিট পর সবুজ টিক এলে workflow-তে ক্লিক করে নিচের **Artifacts** থেকে `AYT-APK` ডাউনলোড করুন। ZIP খুলে `app-release.apk` ফোনে ইনস্টল করুন।

## ডিফল্ট পাসওয়ার্ড
- অ্যাডমিন: `admin123`
- হিসাব: `acc123`
(অ্যাডমিন পেজের চাবি আইকন থেকে পরিবর্তন করুন)
