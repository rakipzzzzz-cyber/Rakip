import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:share_plus/share_plus.dart';

typedef M = Map<String, dynamic>;
late SharedPreferences sp;
List<M> products = [], sales = [], expenses = [];
final themeMode = ValueNotifier<ThemeMode>(ThemeMode.system);

List<M> load(String k) => (jsonDecode(sp.getString(k) ?? '[]') as List).map((e) => M.from(e)).toList();
void save() {
  sp.setString('p', jsonEncode(products));
  sp.setString('s', jsonEncode(sales));
  sp.setString('e', jsonEncode(expenses));
}

String tk(num v) => '৳${v.toStringAsFixed(v % 1 == 0 ? 0 : 2)}';
num pn(String t) => num.tryParse(t.trim()) ?? 0;
num saleTotal(M s) => (s['items'] as List).fold<num>(0, (a, i) => a + i['qty'] * i['price']) - s['discount'];
num saleCost(M s) => (s['items'] as List).fold<num>(0, (a, i) => a + i['qty'] * i['buy']);
String newId() => DateTime.now().microsecondsSinceEpoch.toString();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  sp = await SharedPreferences.getInstance();
  products = load('p');
  sales = load('s');
  expenses = load('e');
  themeMode.value = ThemeMode.values[sp.getInt('t') ?? 0];
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});
  ThemeData th(Brightness b) => ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFE91E63), brightness: b),
        scaffoldBackgroundColor: b == Brightness.dark ? const Color(0xFF141015) : const Color(0xFFFFF5F8),
      );
  @override
  Widget build(BuildContext c) => ValueListenableBuilder<ThemeMode>(
        valueListenable: themeMode,
        builder: (_, m, __) => MaterialApp(
          title: 'AYT এন্টারপ্রাইজ',
          debugShowCheckedModeBanner: false,
          themeMode: m,
          theme: th(Brightness.light),
          darkTheme: th(Brightness.dark),
          home: const Home(),
        ),
      );
}

Future<List<String>?> form(BuildContext c, String title, List<String> labels, [List<String>? init]) {
  final cs = [for (var i = 0; i < labels.length; i++) TextEditingController(text: init?[i] ?? '')];
  return showDialog<List<String>>(
    context: c,
    builder: (d) => AlertDialog(
      title: Text(title),
      content: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          for (var i = 0; i < labels.length; i++)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: TextField(
                controller: cs[i],
                keyboardType: labels[i].startsWith('#') ? TextInputType.number : TextInputType.text,
                decoration: InputDecoration(labelText: labels[i].replaceFirst('#', ''), border: const OutlineInputBorder()),
              ),
            ),
        ]),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(d), child: const Text('বাতিল')),
        FilledButton(onPressed: () => Navigator.pop(d, cs.map((e) => e.text).toList()), child: const Text('ঠিক আছে')),
      ],
    ),
  );
}

Future<bool> ask(BuildContext c, String key) async {
  final t = TextEditingController();
  final pass = sp.getString('pw_$key') ?? (key == 'admin' ? 'admin123' : 'acc123');
  final r = await showDialog<String>(
    context: c,
    builder: (d) => AlertDialog(
      title: const Text('পাসওয়ার্ড দিন'),
      content: TextField(controller: t, obscureText: true, autofocus: true),
      actions: [
        TextButton(onPressed: () => Navigator.pop(d), child: const Text('বাতিল')),
        FilledButton(onPressed: () => Navigator.pop(d, t.text), child: const Text('প্রবেশ')),
      ],
    ),
  );
  if (r == null) return false;
  if (r != pass && c.mounted) {
    ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content: Text('ভুল পাসওয়ার্ড')));
  }
  return r == pass;
}

class Live extends StatefulWidget {
  final Widget Function(BuildContext, VoidCallback) b;
  const Live(this.b, {super.key});
  @override
  State<Live> createState() => _LiveS();
}

class _LiveS extends State<Live> {
  @override
  Widget build(BuildContext c) => widget.b(c, () => setState(() {}));
}

class Home extends StatelessWidget {
  const Home({super.key});
  @override
  Widget build(BuildContext c) {
    final cs = Theme.of(c).colorScheme;
    Widget tile(IconData i, String t, String s, Widget Function() page, [String? key]) => Card(
          elevation: 0,
          child: InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: () async {
              if (key != null && !await ask(c, key)) return;
              if (c.mounted) Navigator.push(c, MaterialPageRoute(builder: (_) => page()));
            },
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Row(children: [
                CircleAvatar(radius: 28, backgroundColor: cs.primaryContainer, child: Icon(i, color: cs.primary, size: 28)),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(t, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    Text(s),
                  ]),
                ),
                const Icon(Icons.chevron_right),
              ]),
            ),
          ),
        );
    return Scaffold(
      body: Column(children: [
        Container(
          width: double.infinity,
          padding: EdgeInsets.fromLTRB(24, MediaQuery.of(c).padding.top + 16, 8, 28),
          decoration: const BoxDecoration(
            gradient: LinearGradient(colors: [Color(0xFFE91E63), Color(0xFFFF6F91)]),
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(28)),
          ),
          child: Row(children: [
            const Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('AYT এন্টারপ্রাইজ', style: TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.bold)),
                Text('আপনার ব্যবসা, এক অ্যাপে', style: TextStyle(color: Colors.white70)),
              ]),
            ),
            PopupMenuButton<int>(
              icon: const Icon(Icons.palette_outlined, color: Colors.white),
              onSelected: (i) {
                themeMode.value = ThemeMode.values[i];
                sp.setInt('t', i);
              },
              itemBuilder: (_) => const [
                PopupMenuItem(value: 0, child: Text('সিস্টেম ডিফল্ট')),
                PopupMenuItem(value: 1, child: Text('লাইট মোড')),
                PopupMenuItem(value: 2, child: Text('ডার্ক মোড')),
              ],
            ),
          ]),
        ),
        Expanded(
          child: ListView(padding: const EdgeInsets.all(16), children: [
            tile(Icons.storefront, 'কাস্টমার', 'পণ্য দেখুন ও অর্ডার করুন', () => const Shop(false)),
            tile(Icons.admin_panel_settings, 'অ্যাডমিন', 'পণ্য, বিক্রি ও অর্ডার', () => const Admin(), 'admin'),
            tile(Icons.bar_chart, 'হিসাব', 'বিক্রি, খরচ, লাভ ও বাকি', () => const Accounts(), 'acc'),
          ]),
        ),
      ]),
    );
  }
}

String memo(M s) {
  final t = saleTotal(s);
  final id = s['id'].toString();
  final d = DateTime.parse(s['date']);
  final lines = (s['items'] as List).map((i) => '${i['name']} x${i['qty']} = ${tk(i['qty'] * i['price'])}').join('\n');
  return 'AYT এন্টারপ্রাইজ\nমেমো নং: ${id.substring(id.length - 6)}\nতারিখ: ${d.day}/${d.month}/${d.year}\n'
      'কাস্টমার: ${s['name']} ${s['phone']}\n-----------\n$lines\n-----------\n'
      'ডিসকাউন্ট: ${tk(s['discount'])}\nমোট বিল: ${tk(t)}\nপরিশোধিত: ${tk(s['paid'])}\nবাকি: ${tk(t - s['paid'])}\nধন্যবাদ!';
}

void deduct(M s) {
  for (final i in s['items']) {
    final f = products.where((x) => x['id'] == i['pid']);
    if (f.isNotEmpty) f.first['stock'] = ((f.first['stock'] as num) - i['qty']).clamp(0, 1 << 30);
  }
}

class Shop extends StatefulWidget {
  final bool pos;
  const Shop(this.pos, {super.key});
  @override
  State<Shop> createState() => _ShopS();
}

class _ShopS extends State<Shop> {
  String q = '';
  final cart = <String, int>{};
  M pr(String id) => products.firstWhere((p) => p['id'] == id);
  num get total => cart.entries.fold<num>(0, (a, e) => a + e.value * pr(e.key)['sell']);
  int get count => cart.values.fold(0, (a, b) => a + b);

  Future<void> checkout() async {
    final pos = widget.pos;
    final r = await form(
      context,
      pos ? 'বিক্রি সম্পন্ন করুন' : 'অর্ডার নিশ্চিত করুন',
      ['কাস্টমারের নাম', '#মোবাইল নম্বর', if (pos) '#ডিসকাউন্ট (৳)', if (pos) '#পরিশোধিত (৳)'],
      ['', '', if (pos) '0', if (pos) '${total}'],
    );
    if (r == null) return;
    final M s = {
      'id': newId(),
      'date': DateTime.now().toIso8601String(),
      'name': r[0],
      'phone': r[1],
      'items': cart.entries.map((e) {
        final p = pr(e.key);
        return {'name': p['name'], 'qty': e.value, 'price': p['sell'], 'buy': p['buy'], 'pid': p['id']};
      }).toList(),
      'discount': pos ? pn(r[2]) : 0,
      'paid': pos ? pn(r[3]) : 0,
      'done': pos,
    };
    if (pos) deduct(s);
    sales.insert(0, s);
    save();
    setState(cart.clear);
    if (pos) {
      Share.share(memo(s));
    } else if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('অর্ডার পাঠানো হয়েছে ✓')));
    }
  }

  @override
  Widget build(BuildContext c) {
    final cs = Theme.of(c).colorScheme;
    final l = products.where((p) => '${p['name']} ${p['cat']}'.contains(q)).toList();
    return Scaffold(
      appBar: widget.pos ? null : AppBar(title: const Text('শপ')),
      bottomNavigationBar: cart.isEmpty
          ? null
          : Padding(
              padding: const EdgeInsets.all(12),
              child: FilledButton.icon(
                style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
                onPressed: checkout,
                icon: const Icon(Icons.shopping_cart_checkout),
                label: Text('${widget.pos ? 'বিক্রি' : 'অর্ডার'} • $count টি • ${tk(total)}'),
              ),
            ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
          child: TextField(
            onChanged: (v) => setState(() => q = v),
            decoration: InputDecoration(
              hintText: 'পণ্য বা ক্যাটাগরি খুঁজুন',
              prefixIcon: const Icon(Icons.search),
              filled: true,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(30), borderSide: BorderSide.none),
            ),
          ),
        ),
        Expanded(
          child: l.isEmpty
              ? const Center(child: Text('কোনো পণ্য নেই'))
              : GridView.builder(
                  padding: const EdgeInsets.all(12),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2, childAspectRatio: 0.78, crossAxisSpacing: 12, mainAxisSpacing: 12),
                  itemCount: l.length,
                  itemBuilder: (_, i) {
                    final p = l[i];
                    final String id = p['id'];
                    final int st = (p['stock'] as num).toInt();
                    final qn = cart[id] ?? 0;
                    return Card(
                      elevation: 0,
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(children: [
                          Expanded(child: Center(child: Icon(Icons.shopping_bag_outlined, size: 48, color: cs.primary))),
                          Text('${p['name']}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold)),
                          Text(tk(p['sell']), style: TextStyle(color: cs.primary, fontWeight: FontWeight.w700, fontSize: 16)),
                          Text(st > 0 ? 'স্টক: $st' : 'স্টক নেই', style: const TextStyle(fontSize: 12)),
                          const SizedBox(height: 8),
                          qn == 0
                              ? FilledButton.tonal(onPressed: st > 0 ? () => setState(() => cart[id] = 1) : null, child: const Text('যোগ করুন'))
                              : Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                                  IconButton.filledTonal(
                                    icon: const Icon(Icons.remove),
                                    onPressed: () => setState(() {
                                      if (qn == 1) {
                                        cart.remove(id);
                                      } else {
                                        cart[id] = qn - 1;
                                      }
                                    }),
                                  ),
                                  Text('$qn', style: const TextStyle(fontWeight: FontWeight.bold)),
                                  IconButton.filledTonal(
                                    icon: const Icon(Icons.add),
                                    onPressed: qn < st ? () => setState(() => cart[id] = qn + 1) : null,
                                  ),
                                ]),
                        ]),
                      ),
                    );
                  },
                ),
        ),
      ]),
    );
  }
}

Future<void> editProduct(BuildContext c, M? p) async {
  final r = await form(
    c,
    p == null ? 'নতুন পণ্য' : 'পণ্য সম্পাদনা',
    ['পণ্যের নাম', '#ক্রয় মূল্য (৳)', '#বিক্রয় মূল্য (৳)', '#স্টক (সংখ্যা)', 'ক্যাটাগরি'],
    p == null ? null : ['${p['name']}', '${p['buy']}', '${p['sell']}', '${p['stock']}', '${p['cat']}'],
  );
  if (r == null || r[0].trim().isEmpty) return;
  final M m = {
    'id': p?['id'] ?? newId(),
    'name': r[0].trim(),
    'buy': pn(r[1]),
    'sell': pn(r[2]),
    'stock': pn(r[3]).toInt(),
    'cat': r[4].trim(),
  };
  if (p == null) {
    products.add(m);
  } else {
    p.addAll(m);
  }
  save();
}

class Admin extends StatelessWidget {
  const Admin({super.key});
  @override
  Widget build(BuildContext c) => DefaultTabController(
        length: 3,
        child: Scaffold(
          appBar: AppBar(
            title: const Text('অ্যাডমিন'),
            actions: [
              IconButton(
                icon: const Icon(Icons.key),
                tooltip: 'পাসওয়ার্ড পরিবর্তন',
                onPressed: () async {
                  final r = await form(c, 'নতুন পাসওয়ার্ড (ফাঁকা = অপরিবর্তিত)', ['অ্যাডমিন পাসওয়ার্ড', 'হিসাব পাসওয়ার্ড']);
                  if (r == null) return;
                  if (r[0].isNotEmpty) sp.setString('pw_admin', r[0]);
                  if (r[1].isNotEmpty) sp.setString('pw_acc', r[1]);
                },
              ),
            ],
            bottom: const TabBar(tabs: [Tab(text: 'পণ্য'), Tab(text: 'বিক্রি'), Tab(text: 'অর্ডার')]),
          ),
          body: TabBarView(children: [
            Live((c, up) => Scaffold(
                  backgroundColor: Colors.transparent,
                  floatingActionButton: FloatingActionButton.extended(
                    icon: const Icon(Icons.add),
                    label: const Text('নতুন পণ্য'),
                    onPressed: () async {
                      await editProduct(c, null);
                      up();
                    },
                  ),
                  body: ListView(padding: const EdgeInsets.only(bottom: 90), children: [
                    for (final p in products)
                      ListTile(
                        leading: const Icon(Icons.shopping_bag_outlined),
                        title: Text('${p['name']}'),
                        subtitle: Text('ক্রয় ${tk(p['buy'])} • বিক্রয় ${tk(p['sell'])} • স্টক ${p['stock']}  ${p['cat']}'),
                        textColor: (p['stock'] as num) <= 5 ? Colors.red : null,
                        onTap: () async {
                          await editProduct(c, p);
                          up();
                        },
                        trailing: IconButton(
                          icon: const Icon(Icons.delete_outline),
                          onPressed: () {
                            products.remove(p);
                            save();
                            up();
                          },
                        ),
                      ),
                  ]),
                )),
            const Shop(true),
            Live((c, up) {
              final l = sales.where((s) => s['done'] == false).toList();
              if (l.isEmpty) return const Center(child: Text('কোনো নতুন অর্ডার নেই'));
              return ListView(children: [
                for (final s in l)
                  Card(
                    margin: const EdgeInsets.all(8),
                    child: ListTile(
                      isThreeLine: true,
                      title: Text('${s['name']} • ${s['phone']}'),
                      subtitle: Text('${(s['items'] as List).map((i) => '${i['name']} x${i['qty']}').join(', ')}\nমোট: ${tk(saleTotal(s))}'),
                      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                        IconButton(
                          icon: const Icon(Icons.check_circle, color: Colors.green),
                          onPressed: () {
                            deduct(s);
                            s['done'] = true;
                            save();
                            up();
                          },
                        ),
                        IconButton(
                          icon: const Icon(Icons.cancel_outlined),
                          onPressed: () {
                            sales.remove(s);
                            save();
                            up();
                          },
                        ),
                      ]),
                    ),
                  ),
              ]);
            }),
          ]),
        ),
      );
}

class Accounts extends StatelessWidget {
  const Accounts({super.key});
  @override
  Widget build(BuildContext c) => DefaultTabController(
        length: 3,
        child: Scaffold(
          appBar: AppBar(
            title: const Text('হিসাব'),
            bottom: const TabBar(tabs: [Tab(text: 'সারাংশ'), Tab(text: 'খরচ'), Tab(text: 'বাকি')]),
          ),
          body: TabBarView(children: [
            Live((c, up) {
              final now = DateTime.now();
              Widget row(String t, bool Function(DateTime) f) {
                num sl = 0, co = 0, ex = 0;
                for (final s in sales.where((s) => s['done'] == true && f(DateTime.parse(s['date'])))) {
                  sl += saleTotal(s);
                  co += saleCost(s);
                }
                for (final e in expenses.where((e) => f(DateTime.parse(e['date'])))) {
                  ex += e['amount'];
                }
                final profit = sl - co - ex;
                return Card(
                  elevation: 0,
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(t, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      Text('বিক্রি: ${tk(sl)}'),
                      Text('পণ্যের খরচ: ${tk(co)}'),
                      Text('অন্যান্য খরচ: ${tk(ex)}'),
                      Text('${profit >= 0 ? 'লাভ' : 'লোকসান'}: ${tk(profit.abs())}',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: profit >= 0 ? Colors.green : Colors.red)),
                    ]),
                  ),
                );
              }

              final stockVal = products.fold<num>(0, (a, p) => a + p['buy'] * p['stock']);
              return ListView(padding: const EdgeInsets.all(12), children: [
                row('আজ', (d) => d.year == now.year && d.month == now.month && d.day == now.day),
                row('এই মাস', (d) => d.year == now.year && d.month == now.month),
                row('মোট', (d) => true),
                Card(elevation: 0, child: ListTile(title: const Text('স্টকের মূল্য (ক্রয় দামে)'), trailing: Text(tk(stockVal)))),
              ]);
            }),
            Live((c, up) => Scaffold(
                  backgroundColor: Colors.transparent,
                  floatingActionButton: FloatingActionButton.extended(
                    icon: const Icon(Icons.add),
                    label: const Text('খরচ যোগ'),
                    onPressed: () async {
                      final r = await form(c, 'নতুন খরচ', ['খরচের বিবরণ', '#টাকা (৳)']);
                      if (r == null || pn(r[1]) <= 0) return;
                      expenses.insert(0, {'title': r[0], 'amount': pn(r[1]), 'date': DateTime.now().toIso8601String()});
                      save();
                      up();
                    },
                  ),
                  body: ListView(padding: const EdgeInsets.only(bottom: 90), children: [
                    for (final e in expenses)
                      ListTile(
                        title: Text('${e['title']}'),
                        subtitle: Text(e['date'].toString().substring(0, 10)),
                        leading: Text(tk(e['amount']), style: const TextStyle(fontWeight: FontWeight.bold)),
                        trailing: IconButton(
                          icon: const Icon(Icons.delete_outline),
                          onPressed: () {
                            expenses.remove(e);
                            save();
                            up();
                          },
                        ),
                      ),
                  ]),
                )),
            Live((c, up) {
              final l = sales.where((s) => s['done'] == true && saleTotal(s) - s['paid'] > 0).toList();
              if (l.isEmpty) return const Center(child: Text('কোনো বাকি নেই 🎉'));
              return ListView(children: [
                for (final s in l)
                  ListTile(
                    title: Text('${s['name']} • ${s['phone']}'),
                    subtitle: Text('বাকি: ${tk(saleTotal(s) - s['paid'])}'),
                    trailing: FilledButton.tonal(
                      child: const Text('জমা'),
                      onPressed: () async {
                        final r = await form(c, 'টাকা জমা', ['#জমার পরিমাণ (৳)']);
                        if (r == null) return;
                        s['paid'] = s['paid'] + pn(r[0]);
                        save();
                        up();
                      },
                    ),
                  ),
              ]);
            }),
          ]),
        ),
      );
}
